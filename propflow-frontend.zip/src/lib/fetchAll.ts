import type { Paginated } from "@/types/api";

/**
 * Pages through a list endpoint (100 rows per request) and returns every row.
 * Stops at `maxRows` so one export can never hammer the API; `truncated` says it did.
 */
export async function fetchAll<T>(
  page: (page: number, limit: number) => Promise<Paginated<T>>,
  maxRows = 5000,
): Promise<{ rows: T[]; truncated: boolean }> {
  const limit = 100;
  const rows: T[] = [];
  for (let p = 1; ; p++) {
    const r = await page(p, limit);
    rows.push(...r.data);
    if (p >= r.meta.totalPages || r.data.length === 0) return { rows, truncated: false };
    if (rows.length >= maxRows) return { rows: rows.slice(0, maxRows), truncated: true };
  }
}
