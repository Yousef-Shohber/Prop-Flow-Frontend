import * as RD from "@radix-ui/react-dialog";
import { useQuery } from "@tanstack/react-query";
import {
  Building2,
  CornerDownLeft,
  Languages,
  LogOut,
  Moon,
  Plus,
  Search,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { propertiesApi } from "@/api/properties";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { useI18n } from "@/i18n";
import { cn } from "@/lib/utils";
import { paths } from "@/routes/paths";
import type { UserRole } from "@/types/enums";
import { NAV_GROUPS } from "./nav";

interface Command {
  id: string;
  group: "pages" | "actions" | "properties";
  label: string;
  hint?: string;
  icon: LucideIcon;
  run: () => void;
}

/** Everything the signed-in role may do, with its own creation shortcuts. */
function creationShortcuts(role: UserRole | undefined): { id: string; labelKey: string; to: string }[] {
  if (role === "TENANT")
    return [
      { id: "new-request", labelKey: "palette.newRequest", to: paths.rentalRequestNew() },
      { id: "new-maintenance", labelKey: "palette.newMaintenance", to: paths.maintenanceNew },
    ];
  if (role === "OWNER" || role === "ADMIN")
    return [
      { id: "new-property", labelKey: "palette.newProperty", to: paths.propertyNew },
      { id: "new-lease", labelKey: "palette.newLease", to: paths.leaseNew },
    ];
  return [];
}

/**
 * Ctrl/Cmd+K quick navigation: pages the role can open, shortcuts for the common "new ..." actions,
 * app preferences and a live property search. Every item is built from the same role rules as the
 * sidebar, so the palette can never open a page the user is not allowed to see.
 */
export function CommandPalette({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { t, lang, toggleLang } = useI18n();
  const { user, logout } = useAuth();
  const { cycle } = useTheme();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [active, setActive] = useState(0);
  const listRef = useRef<HTMLUListElement>(null);
  const role = user?.role;

  useEffect(() => {
    if (!open) {
      setQuery("");
      setDebounced("");
      setActive(0);
    }
  }, [open]);
  useEffect(() => {
    const id = window.setTimeout(() => setDebounced(query.trim()), 250);
    return () => window.clearTimeout(id);
  }, [query]);

  const go = (to: string) => {
    onOpenChange(false);
    navigate(to);
  };

  // staff cannot read properties (the API answers 403), so they never get the search
  const canSearchProperties = !!role && role !== "MAINTENANCE_STAFF";
  const found = useQuery({
    queryKey: ["properties", "palette", debounced],
    queryFn: () =>
      propertiesApi.list({ search: debounced, limit: 5, sortBy: "name", sortOrder: "ASC" }),
    enabled: open && canSearchProperties && debounced.length >= 2,
  });

  const commands = useMemo<Command[]>(() => {
    const out: Command[] = [];
    for (const g of NAV_GROUPS)
      for (const item of g.items)
        if (role && item.roles.includes(role))
          out.push({
            id: `page:${item.to}`,
            group: "pages",
            label: t(item.labelKey),
            hint: t(g.labelKey),
            icon: item.icon,
            run: () => go(item.to),
          });
    for (const s of creationShortcuts(role))
      out.push({ id: s.id, group: "actions", label: t(s.labelKey), icon: Plus, run: () => go(s.to) });
    out.push(
      {
        id: "lang",
        group: "actions",
        label: t("palette.switchLang", { lang: lang === "ar" ? "English" : "العربية" }),
        icon: Languages,
        run: () => {
          onOpenChange(false);
          toggleLang();
        },
      },
      {
        id: "theme",
        group: "actions",
        label: t("palette.theme"),
        icon: Moon,
        run: () => {
          onOpenChange(false);
          cycle();
        },
      },
      {
        id: "logout",
        group: "actions",
        label: t("nav.logout"),
        icon: LogOut,
        run: () => {
          onOpenChange(false);
          void logout();
        },
      },
    );
    for (const p of found.data?.data ?? [])
      out.push({
        id: `property:${p.id}`,
        group: "properties",
        label: p.name,
        hint: p.city,
        icon: Building2,
        run: () => go(paths.property(p.id)),
      });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role, lang, t, found.data]);

  const needle = query.trim().toLowerCase();
  const visible = commands.filter(
    (c) => c.group === "properties" || !needle || c.label.toLowerCase().includes(needle),
  );
  useEffect(() => setActive(0), [needle, visible.length]);
  useEffect(() => {
    listRef.current?.querySelector(`[data-index="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active]);

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive((i) => Math.min(visible.length - 1, i + 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((i) => Math.max(0, i - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      visible[active]?.run();
    }
  };

  const groupLabel = (g: Command["group"]) => t(`palette.group.${g}`);
  let lastGroup: string | null = null;

  return (
    <RD.Root open={open} onOpenChange={onOpenChange}>
      <RD.Portal>
        <RD.Overlay
          className="fixed inset-0 z-50 bg-[#0a1020]/55"
          style={{ animation: "fade-in .15s ease-out" }}
        />
        <RD.Content
          aria-describedby={undefined}
          onKeyDown={onKey}
          className="fixed left-1/2 top-[12vh] z-50 w-[calc(100vw-2rem)] max-w-xl -translate-x-1/2 overflow-hidden rounded-sheet border border-line bg-surface shadow-pop focus:outline-none"
        >
          <RD.Title className="sr-only">{t("palette.title")}</RD.Title>
          <div className="flex items-center gap-3 border-b border-line px-4">
            <Search className="size-4 shrink-0 text-faint" aria-hidden />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("palette.placeholder")}
              aria-label={t("palette.title")}
              role="combobox"
              aria-expanded
              aria-controls="palette-list"
              aria-activedescendant={visible[active] ? `cmd-${active}` : undefined}
              className="h-14 w-full bg-transparent text-sm outline-none placeholder:text-faint"
            />
          </div>
          <ul
            ref={listRef}
            id="palette-list"
            role="listbox"
            className="max-h-[50vh] overflow-y-auto p-2"
          >
            {visible.length === 0 && (
              <li className="px-3 py-8 text-center text-sm text-muted">
                {found.isFetching ? t("common.loading") : t("palette.empty")}
              </li>
            )}
            {visible.map((c, i) => {
              const header = c.group !== lastGroup;
              lastGroup = c.group;
              const Icon = c.icon;
              return (
                <li key={c.id} role="presentation">
                  {header && (
                    <p className="px-3 pb-1 pt-3 text-xs font-semibold text-faint first:pt-1">
                      {groupLabel(c.group)}
                    </p>
                  )}
                  <button
                    type="button"
                    id={`cmd-${i}`}
                    role="option"
                    aria-selected={i === active}
                    data-index={i}
                    onMouseMove={() => setActive(i)}
                    onClick={c.run}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-start text-sm",
                      i === active ? "bg-accent-soft text-ink" : "text-ink hover:bg-surface-2",
                    )}
                  >
                    <Icon className="size-4 shrink-0 text-muted" aria-hidden />
                    <span className="min-w-0 flex-1 truncate" dir="auto">{c.label}</span>
                    {c.hint && <span className="shrink-0 text-xs text-faint" dir="auto">{c.hint}</span>}
                    {i === active && (
                      <CornerDownLeft className="size-3.5 shrink-0 text-faint rtl:-scale-x-100" aria-hidden />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </RD.Content>
      </RD.Portal>
    </RD.Root>
  );
}

/** Opens the palette with Ctrl+K / Cmd+K from anywhere in the app. */
export function usePaletteShortcut(toggle: () => void) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        toggle();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle]);
}
