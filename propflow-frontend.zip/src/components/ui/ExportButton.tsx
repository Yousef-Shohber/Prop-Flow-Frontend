import { Download } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { toast } from "@/hooks/useToast";
import { useI18n } from "@/i18n";
import { type CsvColumn, downloadCsv, toCsv } from "@/lib/csv";
import { useApiError } from "@/lib/useApiError";

/**
 * "Export CSV" for a list page: fetches every row that matches the page's current filters
 * (not just the visible page), turns them into a CSV and downloads it. Headers are in the
 * current language, so an Arabic export has Arabic columns.
 */
export function ExportButton<T>({
  filename,
  fetchRows,
  columns,
  disabled,
}: {
  filename: string;
  fetchRows: () => Promise<{ rows: T[]; truncated: boolean }>;
  columns: CsvColumn<T>[];
  disabled?: boolean;
}) {
  const { t } = useI18n();
  const apiError = useApiError();
  const [busy, setBusy] = useState(false);
  return (
    <Button
      variant="secondary"
      loading={busy}
      disabled={disabled}
      onClick={async () => {
        setBusy(true);
        try {
          const { rows, truncated } = await fetchRows();
          if (rows.length === 0) {
            toast.info(t("export.empty"));
            return;
          }
          const stamp = new Date().toISOString().slice(0, 10);
          downloadCsv(`${filename}-${stamp}`, toCsv(rows, columns));
          toast.success(
            truncated
              ? t("export.partial", { n: rows.length })
              : t("export.done", { n: rows.length }),
          );
        } catch (e) {
          toast.error(apiError(e));
        } finally {
          setBusy(false);
        }
      }}
    >
      <Download className="size-4" aria-hidden />
      {t("export.button")}
    </Button>
  );
}
