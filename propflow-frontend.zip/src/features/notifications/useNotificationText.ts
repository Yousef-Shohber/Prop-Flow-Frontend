import { useI18n } from "@/i18n";
import type { AppNotification } from "@/types/models";

/**
 * The API sends English notification text. In Arabic we show the matching localized
 * sentence for the notification type; in English the server text is used as-is.
 * Every place that shows a notification must use this, so the two languages never mix.
 */
export function useNotificationText() {
  const { t, lang, has } = useI18n();
  return (n: Pick<AppNotification, "type" | "title" | "message">) => {
    const localized = lang === "ar" && has(`notifText.${n.type}.title`);
    return {
      localized,
      title: localized ? t(`notifText.${n.type}.title`) : n.title,
      message: localized ? t(`notifText.${n.type}.message`) : n.message,
    };
  };
}
