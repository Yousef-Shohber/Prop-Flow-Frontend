/** Pure date/geometry helpers for the occupancy timeline. Everything is UTC midnight in ms. */
export const DAY = 86_400_000;

export const utc = (iso: string): number => {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  return Date.UTC(y, m - 1, d);
};

export interface TimelineWindow {
  start: number;
  /** exclusive */
  end: number;
  days: number;
}

/** `monthStart` is YYYY-MM-01. */
export function makeWindow(monthStart: string, months: number): TimelineWindow {
  const [y, m] = monthStart.split("-").map(Number);
  const start = Date.UTC(y, m - 1, 1);
  const end = Date.UTC(y, m - 1 + months, 1);
  return { start, end, days: (end - start) / DAY };
}

export function shiftMonths(monthStart: string, delta: number): string {
  const [y, m] = monthStart.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1 + delta, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-01`;
}

export interface MonthCell {
  key: string;
  /** first day, ms */
  start: number;
  /** share of the whole window, 0-100 */
  width: number;
}

export function monthCells(w: TimelineWindow): MonthCell[] {
  const cells: MonthCell[] = [];
  for (let t = w.start; t < w.end; ) {
    const d = new Date(t);
    const next = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
    cells.push({
      key: `${d.getUTCFullYear()}-${d.getUTCMonth() + 1}`,
      start: t,
      width: ((next - t) / (w.end - w.start)) * 100,
    });
    t = next;
  }
  return cells;
}

export interface BarGeometry {
  left: number;
  width: number;
  clippedStart: boolean;
  clippedEnd: boolean;
}

/** Position of a lease inside the window (end date inclusive), or null when it is outside. */
export function barGeometry(
  w: TimelineWindow,
  startISO: string,
  endISO: string,
): BarGeometry | null {
  const s = utc(startISO);
  const e = utc(endISO) + DAY;
  if (e <= w.start || s >= w.end) return null;
  const cs = Math.max(s, w.start);
  const ce = Math.min(e, w.end);
  const span = w.end - w.start;
  return {
    left: ((cs - w.start) / span) * 100,
    width: ((ce - cs) / span) * 100,
    clippedStart: s < w.start,
    clippedEnd: e > w.end,
  };
}

export const percentOfWindow = (w: TimelineWindow, ms: number): number | null =>
  ms < w.start || ms >= w.end ? null : ((ms - w.start) / (w.end - w.start)) * 100;

/** Greedy lane assignment so leases that overlap in time (an ended one next to a new one) stack. */
export function assignLanes<T extends { start: number; end: number }>(
  items: T[],
): { item: T; lane: number }[] {
  const laneEnds: number[] = [];
  return [...items]
    .sort((a, b) => a.start - b.start)
    .map((item) => {
      let lane = laneEnds.findIndex((end) => end <= item.start);
      if (lane === -1) lane = laneEnds.length;
      laneEnds[lane] = item.end;
      return { item, lane };
    });
}
