import { useQuery } from "@tanstack/react-query";
import { CalendarRange, ChevronLeft, ChevronRight } from "lucide-react";
import { useMemo } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { leasesApi } from "@/api/leases";
import { propertiesApi } from "@/api/properties";
import { unitsApi } from "@/api/units";
import { Button } from "@/components/ui/Button";
import { Select } from "@/components/ui/Field";
import { Card } from "@/components/ui/Misc";
import { PageHeader } from "@/components/ui/PageHeader";
import { EmptyState, ErrorState, LoadingSkeleton } from "@/components/ui/States";
import { useAllTenants } from "@/hooks/queries";
import { useEnumLabel, useI18n } from "@/i18n";
import { addDaysISO, todayISO } from "@/lib/dates";
import { fetchAll } from "@/lib/fetchAll";
import { formatDate, formatMoney, fullName } from "@/lib/format";
import { cn } from "@/lib/utils";
import { paths } from "@/routes/paths";
import type { LeaseStatus } from "@/types/enums";
import type { Lease, Unit } from "@/types/models";
import {
  assignLanes,
  barGeometry,
  makeWindow,
  monthCells,
  percentOfWindow,
  shiftMonths,
  utc,
} from "./timelineMath";

const SPANS = [3, 6, 12] as const;
const LANE_H = 30;
const LABEL_W = "11.5rem";

/** Bar colors reuse the status tokens, so light and dark mode both work. */
const BAR: Record<LeaseStatus, string> = {
  ACTIVE: "bg-[var(--green-bg)] text-[var(--green-fg)] border-[var(--green-fg)]/40",
  PENDING: "bg-[var(--amber-bg)] text-[var(--amber-fg)] border-[var(--amber-fg)]/40",
  EXPIRED: "bg-[var(--gray-bg)] text-[var(--gray-fg)] border-[var(--gray-fg)]/30",
  TERMINATED: "bg-[var(--red-bg)] text-[var(--red-fg)] border-[var(--red-fg)]/30",
};

export default function TimelinePage() {
  const { t, lang } = useI18n();
  const label = useEnumLabel();
  const [sp, setSp] = useSearchParams();
  const today = todayISO();

  const span = SPANS.find((s) => s === Number(sp.get("span"))) ?? 6;
  const fromParam = sp.get("from") ?? "";
  const from = /^\d{4}-\d{2}-01$/.test(fromParam)
    ? fromParam
    : shiftMonths(`${today.slice(0, 7)}-01`, -1);
  const propertyId = sp.get("property") ?? "";
  const win = useMemo(() => makeWindow(from, span), [from, span]);
  const cells = useMemo(() => monthCells(win), [win]);

  const setParam = (patch: Record<string, string | undefined>) =>
    setSp(
      (prev) => {
        const next = new URLSearchParams(prev);
        for (const [k, v] of Object.entries(patch)) {
          if (v) next.set(k, v);
          else next.delete(k);
        }
        return next;
      },
      { replace: true },
    );

  const props = useQuery({
    queryKey: ["properties", "list", { limit: 100, for: "filter" }],
    queryFn: () =>
      propertiesApi.list({ limit: 100, sortBy: "name", sortOrder: "ASC" }),
  });
  const units = useQuery({
    queryKey: ["units", "timeline", { propertyId }],
    queryFn: () =>
      fetchAll((page, limit) =>
        unitsApi.list({
          page,
          limit,
          sortBy: "unitNumber",
          sortOrder: "ASC",
          propertyId: propertyId || undefined,
        }),
      ),
  });
  const leases = useQuery({
    queryKey: ["leases", "timeline"],
    queryFn: () =>
      fetchAll((page, limit) =>
        leasesApi.list({ page, limit, sortBy: "startDate", sortOrder: "ASC" }),
      ),
  });
  const tenants = useAllTenants();

  const tenantName = (id: string) =>
    fullName(tenants.data?.find((u) => u.id === id)) || t("timeline.tenant");
  const propName = (id: string) =>
    props.data?.data.find((p) => p.id === id)?.name ?? "";

  // units grouped by property, in the order of the property filter list
  const groups = useMemo(() => {
    const byProp = new Map<string, Unit[]>();
    for (const u of units.data?.rows ?? []) {
      byProp.set(u.propertyId, [...(byProp.get(u.propertyId) ?? []), u]);
    }
    return [...byProp.entries()]
      .map(([id, list]) => ({
        id,
        name: props.data?.data.find((p) => p.id === id)?.name ?? "",
        units: list,
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [units.data, props.data]);

  const leasesByUnit = useMemo(() => {
    const m = new Map<string, Lease[]>();
    for (const l of leases.data?.rows ?? []) {
      m.set(l.unitId, [...(m.get(l.unitId) ?? []), l]);
    }
    return m;
  }, [leases.data]);

  // leases that end in the next 30 days: what an owner should act on
  const endingSoon = useMemo(() => {
    const limit = addDaysISO(today, 30);
    return (leases.data?.rows ?? [])
      .filter((l) => l.status === "ACTIVE" && l.endDate >= today && l.endDate <= limit)
      .sort((a, b) => a.endDate.localeCompare(b.endDate));
  }, [leases.data, today]);

  const monthFmt = new Intl.DateTimeFormat(
    lang === "ar" ? "ar-EG-u-nu-latn" : "en-GB",
    { month: "short", year: "2-digit", timeZone: "UTC" },
  );
  const todayPct = percentOfWindow(win, utc(today));
  const rangeLabel = `${monthFmt.format(win.start)} – ${monthFmt.format(win.end - 1)}`;
  const loading = units.isLoading || leases.isLoading;
  const error = units.error ?? leases.error;
  const Prev = lang === "ar" ? ChevronRight : ChevronLeft;
  const Next = lang === "ar" ? ChevronLeft : ChevronRight;

  return (
    <>
      <PageHeader
        icon={CalendarRange}
        title={t("timeline.title")}
        subtitle={t("timeline.sub")}
      />

      <Card className="mb-5 flex flex-wrap items-end gap-3 p-4">
        <div className="min-w-48 flex-1 sm:max-w-64">
          <Select
            label={t("timeline.property")}
            value={propertyId}
            onChange={(e) => setParam({ property: e.target.value || undefined })}
          >
            <option value="">{t("timeline.allProperties")}</option>
            {props.data?.data.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </Select>
        </div>
        <div className="w-36">
          <Select
            label={t("timeline.span")}
            value={String(span)}
            onChange={(e) => setParam({ span: e.target.value })}
          >
            {SPANS.map((s) => (
              <option key={s} value={s}>
                {t("timeline.months", { n: s })}
              </option>
            ))}
          </Select>
        </div>
        <div className="ms-auto flex items-center gap-2">
          <Button
            variant="secondary"
            aria-label={t("timeline.prev")}
            onClick={() => setParam({ from: shiftMonths(from, -Math.max(1, span / 3)) })}
          >
            <Prev className="size-4" aria-hidden />
          </Button>
          <span className="num min-w-36 text-center text-sm font-medium" aria-live="polite">
            {rangeLabel}
          </span>
          <Button
            variant="secondary"
            aria-label={t("timeline.next")}
            onClick={() => setParam({ from: shiftMonths(from, Math.max(1, span / 3)) })}
          >
            <Next className="size-4" aria-hidden />
          </Button>
          <Button
            variant="ghost"
            onClick={() => setParam({ from: undefined })}
          >
            {t("timeline.today")}
          </Button>
        </div>
      </Card>

      {error ? (
        <ErrorState error={error} onRetry={() => { void units.refetch(); void leases.refetch(); }} />
      ) : loading ? (
        <LoadingSkeleton />
      ) : groups.length === 0 ? (
        <EmptyState
          icon={CalendarRange}
          title={t("timeline.empty")}
          description={t("timeline.emptyDesc")}
        />
      ) : (
        <Card className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <div className="min-w-[44rem]">
              {/* month header */}
              <div className="flex border-b border-line bg-surface-2 text-xs font-medium text-muted">
                <div className="shrink-0 px-3 py-2" style={{ width: LABEL_W }}>
                  {t("timeline.unit")}
                </div>
                <div className="relative flex min-w-0 flex-1">
                  {cells.map((c) => (
                    <div
                      key={c.key}
                      className="border-s border-line px-2 py-2 text-start"
                      style={{ width: `${c.width}%` }}
                    >
                      <span className="num truncate">{monthFmt.format(c.start)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {groups.map((g) => (
                <section key={g.id} aria-label={g.name}>
                  <div className="flex items-center border-b border-line bg-surface-2/60 px-3 py-1.5">
                    <Link
                      to={paths.property(g.id)}
                      className="truncate text-sm font-semibold hover:underline"
                      dir="auto"
                    >
                      {g.name || propName(g.id)}
                    </Link>
                  </div>
                  {g.units.map((u) => {
                    const placed = assignLanes(
                      (leasesByUnit.get(u.id) ?? [])
                        .map((l) => ({
                          lease: l,
                          geo: barGeometry(win, l.startDate, l.endDate),
                          start: utc(l.startDate),
                          end: utc(l.endDate) + 86_400_000,
                        }))
                        .filter((x) => x.geo),
                    );
                    const lanes = Math.max(1, ...placed.map((p) => p.lane + 1));
                    return (
                      <div key={u.id} className="flex border-b border-line last:border-b-0">
                        <div
                          className="shrink-0 px-3 py-1.5"
                          style={{ width: LABEL_W }}
                        >
                          <Link
                            to={paths.unit(u.id)}
                            className="block truncate text-sm font-medium hover:underline"
                            dir="auto"
                          >
                            {u.unitNumber}
                          </Link>
                          <span className="block text-xs text-muted">
                            {label("unit", u.status)}
                          </span>
                        </div>
                        <div
                          className="relative min-w-0 flex-1"
                          style={{ height: lanes * LANE_H + 8 }}
                        >
                          {/* month separators at the same positions as the header cells */}
                          {cells.slice(1).map((c) => (
                            <span
                              key={c.key}
                              aria-hidden
                              className="pointer-events-none absolute inset-y-0 w-px bg-line"
                              style={{
                                insetInlineStart: `${percentOfWindow(win, c.start)}%`,
                              }}
                            />
                          ))}
                          {todayPct !== null && (
                            <span
                              aria-hidden
                              className="pointer-events-none absolute inset-y-0 z-10 w-px bg-accent"
                              style={{ insetInlineStart: `${todayPct}%` }}
                            />
                          )}
                          {placed.length === 0 && (
                            <span className="absolute inset-0 flex items-center px-3 text-xs text-faint">
                              {t("timeline.noLeases")}
                            </span>
                          )}
                          {placed.map(({ item, lane }) => {
                            const l = item.lease;
                            const geo = item.geo!;
                            const who = tenantName(l.tenantId);
                            const range = `${formatDate(l.startDate, lang)} → ${formatDate(l.endDate, lang)}`;
                            return (
                              <Link
                                key={l.id}
                                to={paths.lease(l.id)}
                                title={`${who} · ${range} · ${formatMoney(l.rentAmount, lang)} · ${label("lease", l.status)}`}
                                aria-label={`${who}, ${range}, ${label("lease", l.status)}`}
                                className={cn(
                                  "absolute flex items-center overflow-hidden border px-2 text-xs font-medium transition-shadow hover:z-20 hover:shadow-card focus-visible:z-20 focus-visible:outline-2",
                                  BAR[l.status],
                                  geo.clippedStart ? "rounded-s-none" : "rounded-s-md",
                                  geo.clippedEnd ? "rounded-e-none" : "rounded-e-md",
                                )}
                                style={{
                                  insetInlineStart: `${geo.left}%`,
                                  width: `${geo.width}%`,
                                  top: 4 + lane * LANE_H,
                                  height: LANE_H - 4,
                                }}
                              >
                                <span className="truncate" dir="auto">{who}</span>
                              </Link>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </section>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-line px-4 py-3 text-xs text-muted">
            {(["ACTIVE", "PENDING", "EXPIRED", "TERMINATED"] as const).map((s) => (
              <span key={s} className="inline-flex items-center gap-1.5">
                <span className={cn("size-3 rounded-sm border", BAR[s])} aria-hidden />
                {label("lease", s)}
              </span>
            ))}
            <span className="inline-flex items-center gap-1.5">
              <span className="h-3 w-px bg-accent" aria-hidden />
              {t("timeline.todayMark")}
            </span>
            {units.data?.truncated && (
              <span className="text-[var(--amber-fg)]">{t("timeline.truncated")}</span>
            )}
          </div>
        </Card>
      )}

      {endingSoon.length > 0 && (
        <Card className="mt-5 p-5">
          <h2 className="mb-3 text-sm font-semibold">{t("timeline.endingSoon")}</h2>
          <ul className="divide-y divide-line text-sm">
            {endingSoon.slice(0, 8).map((l) => (
              <li key={l.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <Link to={paths.lease(l.id)} className="font-medium hover:underline" dir="auto">
                  {tenantName(l.tenantId)} · {l.unit.unitNumber}
                </Link>
                <span className="num text-muted">
                  {t("timeline.endsOn", { date: formatDate(l.endDate, lang) })}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </>
  );
}
