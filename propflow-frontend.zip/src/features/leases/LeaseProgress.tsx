import { Hourglass } from "lucide-react";
import { useI18n } from "@/i18n";
import { cmpDate, parseISODate, todayISO } from "@/lib/dates";
import { formatNumber } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { LeaseStatus } from "@/types/enums";

const DAY = 86_400_000;
const days = (a: string, b: string): number => {
  const x = parseISODate(a);
  const y = parseISODate(b);
  return x && y ? Math.round((y.getTime() - x.getTime()) / DAY) : 0;
};

/**
 * Where a lease is in its term: a bar for an active lease, a countdown for one that has not
 * started. Dates are compared in the business timezone, like the server does.
 */
export function LeaseProgress({
  status,
  start,
  end,
}: {
  status: LeaseStatus;
  start: string;
  end: string;
}) {
  const { t, lang } = useI18n();
  const today = todayISO();
  const n = (v: number) => formatNumber(v, lang);

  if (status === "PENDING" && cmpDate(start, today) > 0) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted">
        <Hourglass className="size-4" aria-hidden />
        {t("leases.startsIn", { n: n(days(today, start)) })}
      </p>
    );
  }
  if (status !== "ACTIVE") return null;

  const total = Math.max(1, days(start, end) + 1);
  const elapsed = Math.min(total, Math.max(0, days(start, today) + 1));
  const left = Math.max(0, days(today, end));
  const pct = Math.round((elapsed / total) * 100);
  const soon = left <= 30;

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-baseline justify-between gap-2 text-sm">
        <span className="font-medium">
          {t("leases.dayOf", { day: n(elapsed), total: n(total) })}
        </span>
        <span className={cn("num", soon ? "font-semibold text-[var(--amber-fg)]" : "text-muted")}>
          {left === 0 ? t("leases.endsToday") : t("leases.daysLeft", { n: n(left) })}
        </span>
      </div>
      <div
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={pct}
        aria-label={t("leases.progress")}
        className="h-2.5 overflow-hidden rounded-full bg-surface-2 print:[-webkit-print-color-adjust:exact] print:[print-color-adjust:exact]"
      >
        <div
          className={cn("h-full rounded-full print:[-webkit-print-color-adjust:exact] print:[print-color-adjust:exact]", soon ? "bg-[var(--amber-fg)]" : "bg-[var(--green-fg)]")}
          style={{ width: `${pct}%` }}
        />
      </div>
      {soon && <p className="mt-2 text-xs text-muted">{t("leases.endingSoonHint")}</p>}
    </div>
  );
}
