import type { EnumFamily } from "@/i18n";
import {
  formatDate,
  formatDateTime,
  formatMoney,
  formatNumber,
} from "@/lib/format";
import { paths } from "@/routes/paths";
import type { AuditLog } from "@/types/models";

/**
 * Turns an audit entry into text a person can read, in the current language.
 * Nothing here ever prints raw JSON or an id: the API sends `actor`, `entityLabel`
 * and `refs` with display names, and everything else is formatted by field.
 */
export interface AuditCtx {
  t: (key: string, vars?: Record<string, string | number>) => string;
  has: (key: string) => boolean;
  label: (family: EnumFamily, value: string | null | undefined) => string;
  lang: string;
}

export interface AuditFact {
  key: string;
  label: string;
  value: string;
  href?: string;
}
export interface AuditChange {
  field: string;
  label: string;
  before: string;
  after: string;
  highlight: boolean;
}
export interface AuditDescription {
  /** One line that adds information beyond the action name (null when there is nothing to add). */
  summary: string | null;
  /** True when the summary only repeats the before/after list (the dialog then shows the list alone). */
  summaryIsChanges: boolean;
  facts: AuditFact[];
  changes: AuditChange[];
}

type Meta = Record<string, unknown>;

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;
const DATE_TIME = /^\d{4}-\d{2}-\d{2}T/;
const isObj = (v: unknown): v is Meta =>
  !!v && typeof v === "object" && !Array.isArray(v);

/** Route of the page that shows the record, or null when there is none (users) or it was deleted. */
export function entityHref(
  entity: string,
  id: string | null | undefined,
  action?: string,
): string | null {
  if (!id || (action && /_DELETED$/.test(action))) return null;
  switch (entity) {
    case "Property":
      return paths.property(id);
    case "Unit":
      return paths.unit(id);
    case "Lease":
      return paths.lease(id);
    case "RentalRequest":
      return paths.rentalRequest(id);
    case "LeaseRenewalRequest":
      return paths.renewal(id);
    case "MaintenanceRequest":
      return paths.maintenanceItem(id);
    default:
      return null;
  }
}

const STATUS_FAMILY: Record<string, EnumFamily> = {
  Unit: "unit",
  Lease: "lease",
  RentalRequest: "rr",
  LeaseRenewalRequest: "lrr",
  MaintenanceRequest: "mnt",
};

const DATE_KEYS = new Set([
  "startDate",
  "endDate",
  "requestedEndDate",
  "previousEndDate",
  "newEndDate",
  "scheduledDate",
]);

/** camelCase -> "Camel case", for the rare field without a translation. */
export const humanizeKey = (k: string): string => {
  const s = k.replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/_/g, " ").toLowerCase();
  return s.charAt(0).toUpperCase() + s.slice(1);
};

export function fieldLabel(key: string, ctx: AuditCtx): string {
  const k = `audit.field.${key}`;
  return ctx.has(k) ? ctx.t(k) : humanizeKey(key);
}

/** Formats one metadata value for display. Returns "" for values that must not be shown (raw ids). */
export function formatValue(
  key: string,
  value: unknown,
  entity: string,
  ctx: AuditCtx,
): string {
  const { t, label, lang, has } = ctx;
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "boolean") return value ? t("common.yes") : t("common.no");
  if (typeof value === "number") {
    if (key === "rentAmount") return formatMoney(value, lang);
    if (key === "area") return t("units.sqm", { n: formatNumber(value, lang) });
    return formatNumber(value, lang);
  }
  if (Array.isArray(value)) {
    return value
      .map((v) => formatValue(key, v, entity, ctx))
      .filter((s) => s && s !== "—")
      .join(", ");
  }
  if (isObj(value)) {
    return Object.entries(value)
      .map(([k, v]) => `${fieldLabel(k, ctx)}: ${formatValue(k, v, entity, ctx)}`)
      .join("; ");
  }
  const s = String(value);
  if (UUID.test(s)) return "";
  if (DATE_KEYS.has(key) && DATE_ONLY.test(s)) return formatDate(s, lang);
  if (DATE_TIME.test(s)) return formatDateTime(s, lang);
  if (key === "role" || key === "previousRole") return label("role", s);
  if (key === "propertyType") return label("ptype", s);
  if (key === "priority") return label("pri", s);
  if (key === "category") return label("cat", s);
  if (["status", "previousStatus", "newStatus"].includes(key)) {
    const family = STATUS_FAMILY[entity];
    return family ? label(family, s) : humanizeKey(s);
  }
  if (key === "reason") {
    return has(`audit.why.${s}`) ? t(`audit.why.${s}`) : humanizeKey(s);
  }
  return s;
}

/** Metadata keys that the summary line already says, so the details list does not repeat them. */
const SAID_IN_SUMMARY: Record<string, string[]> = {
  USER_STATUS_CHANGED: ["isActive"],
  OWNER_VERIFICATION_CHANGED: ["ownerVerified"],
  ROLE_CHANGED: ["role", "previousRole", "source"],
  UNIT_STATUS_CHANGED: ["previousStatus", "newStatus", "status"],
  RENTAL_REQUEST_REJECTED: ["reason"],
  LEASE_TERMINATED: ["reason"],
  LEASE_RENEWED: ["previousEndDate", "newEndDate"],
  LEASE_RENEWAL_REQUESTED: ["requestedEndDate"],
};

const REF_HREF: Record<string, (id: string) => string | null> = {
  leaseId: (id) => paths.lease(id),
  unitId: (id) => paths.unit(id),
  propertyId: (id) => paths.property(id),
  assignedStaffId: () => null,
};

export function describeAudit(log: AuditLog, ctx: AuditCtx): AuditDescription {
  const { t, label } = ctx;
  const md: Meta = log.metadata ?? {};
  const refs = log.refs ?? {};
  const entity = log.entity;

  // ---- before -> after changes (PROPERTY_UPDATED / UNIT_UPDATED)
  const changes: AuditChange[] = [];
  if (isObj(md.changes)) {
    for (const [field, v] of Object.entries(md.changes)) {
      const c = isObj(v) ? v : { before: undefined, after: v };
      changes.push({
        field,
        label: fieldLabel(field, ctx),
        before: formatValue(field, c.before, entity, ctx) || "—",
        after: formatValue(field, c.after, entity, ctx) || "—",
        highlight: field === "rentAmount",
      });
    }
  }

  // ---- one-line summary
  let summary: string | null = null;
  switch (log.action) {
    case "USER_STATUS_CHANGED":
      if (typeof md.isActive === "boolean")
        summary = t(md.isActive ? "audit.s.activated" : "audit.s.deactivated");
      break;
    case "OWNER_VERIFICATION_CHANGED":
      if (typeof md.ownerVerified === "boolean")
        summary = t(md.ownerVerified ? "audit.s.verified" : "audit.s.unverified");
      break;
    case "ROLE_CHANGED": {
      const role = typeof md.role === "string" ? label("role", md.role) : null;
      const prev =
        typeof md.previousRole === "string" ? label("role", md.previousRole) : null;
      if (role)
        summary =
          md.source === "SELF_SELECTION"
            ? t("audit.s.roleSelf", { role })
            : prev
              ? t("audit.s.roleFromTo", { from: prev, to: role })
              : t("audit.s.roleSet", { role });
      break;
    }
    case "UNIT_STATUS_CHANGED": {
      const from =
        typeof md.previousStatus === "string" ? label("unit", md.previousStatus) : null;
      const to = typeof md.newStatus === "string" ? label("unit", md.newStatus) : null;
      if (from && to) summary = t("audit.fromTo", { from, to });
      break;
    }
    case "RENTAL_REQUEST_REJECTED":
    case "LEASE_TERMINATED":
      if (typeof md.reason === "string" && ctx.has(`audit.why.${md.reason}`))
        summary = t(`audit.why.${md.reason}`);
      break;
    case "LEASE_RENEWED":
      if (typeof md.newEndDate === "string")
        summary = t("audit.s.until", { date: formatDate(md.newEndDate, ctx.lang) });
      break;
    case "LEASE_RENEWAL_REQUESTED":
      if (typeof md.requestedEndDate === "string")
        summary = t("audit.s.until", {
          date: formatDate(md.requestedEndDate, ctx.lang),
        });
      break;
    case "MAINTENANCE_ASSIGNED": {
      const name = refs.assignedStaffId?.label;
      if (name) summary = t("audit.s.assignedTo", { name });
      break;
    }
    case "RENTAL_REQUEST_CREATED":
      if (typeof md.startDate === "string" && typeof md.endDate === "string")
        summary = t("audit.fromTo", {
          from: formatDate(md.startDate, ctx.lang),
          to: formatDate(md.endDate, ctx.lang),
        });
      break;
    default:
      break;
  }
  let summaryIsChanges = false;
  if (!summary && changes.length) {
    summaryIsChanges = true;
    const shown = changes
      .slice(0, 2)
      .map((c) => `${c.label}: ${c.before} → ${c.after}`)
      .join(" · ");
    summary =
      changes.length > 2
        ? t("audit.s.more", { list: shown, n: changes.length - 2 })
        : shown;
  }

  // ---- readable details
  const hidden = new Set(["changes", ...(SAID_IN_SUMMARY[log.action] ?? [])]);
  const facts: AuditFact[] = [];
  for (const [key, value] of Object.entries(md)) {
    if (hidden.has(key)) continue;
    const ref = refs[key];
    if (ref) {
      facts.push({
        key,
        label: fieldLabel(key, ctx),
        value: ref.label ?? t("audit.deletedRecord"),
        href: ref.label ? (REF_HREF[key]?.(ref.id) ?? undefined) : undefined,
      });
      continue;
    }
    const text = formatValue(key, value, entity, ctx);
    if (!text) continue; // a bare id with no label: never show it
    facts.push({ key, label: fieldLabel(key, ctx), value: text });
  }

  return { summary, summaryIsChanges, facts, changes };
}
