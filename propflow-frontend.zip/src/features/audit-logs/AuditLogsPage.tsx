import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  Check,
  ChevronDown,
  Copy,
  ExternalLink,
  Filter,
  History,
  ScrollText,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { auditLogsApi } from "@/api/auditLogs";
import { Button } from "@/components/ui/Button";
import { ExportButton } from "@/components/ui/ExportButton";
import { fetchAll } from "@/lib/fetchAll";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { Dialog } from "@/components/ui/Dialog";
import { FilterBar, type FilterField } from "@/components/ui/FilterBar";
import { Tag } from "@/components/ui/Misc";
import { CountBadge, PageHeader } from "@/components/ui/PageHeader";
import { EmptyState } from "@/components/ui/States";
import { useAllUsers } from "@/hooks/queries";
import { useListParams } from "@/hooks/useListParams";
import { useEnumLabel, useI18n } from "@/i18n";
import { formatDateTime, fullName } from "@/lib/format";
import { cn } from "@/lib/utils";
import { AuditAction } from "@/types/enums";
import type { AuditLog } from "@/types/models";
import { type AuditCtx, describeAudit, entityHref } from "./describe";

export const ENTITIES = [
  "Property",
  "Unit",
  "Lease",
  "RentalRequest",
  "LeaseRenewalRequest",
  "MaintenanceRequest",
  "User",
];

/** Everything the page needs to turn an entry into readable text, in the current language. */
function useAuditText() {
  const { t, lang, has } = useI18n();
  const label = useEnumLabel();
  const ctx: AuditCtx = { t, has, label, lang };
  const entityName = (e: string) => (has(`entity.${e}`) ? t(`entity.${e}`) : e);
  /** Name of the record an entry is about; a deleted record reads "No longer available", never an id. */
  const targetText = (l: AuditLog) =>
    l.entityLabel ?? t("audit.deletedRecord");
  const actorName = (l: AuditLog) =>
    l.actor ? fullName(l.actor) : t("audit.deletedUser");
  return { ctx, entityName, targetText, actorName };
}

/** Copies a technical id on request; the ids themselves live in a collapsed section. */
function CopyValue({ value }: { value: string }) {
  const { t } = useI18n();
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="inline-flex items-center gap-1.5 rounded-md px-1.5 py-0.5 text-xs text-muted hover:bg-surface-2 hover:text-ink focus-visible:outline-2"
      onClick={() => {
        void navigator.clipboard?.writeText(value);
        setDone(true);
        window.setTimeout(() => setDone(false), 1600);
      }}
    >
      {done ? (
        <Check className="size-3.5" aria-hidden />
      ) : (
        <Copy className="size-3.5" aria-hidden />
      )}
      {done ? t("audit.copied") : t("audit.copy")}
    </button>
  );
}

function TechnicalRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5">
      <dt className="shrink-0 text-xs text-faint">{label}</dt>
      <dd className="flex min-w-0 items-center gap-2">
        <span
          className="num truncate text-xs text-muted"
          dir="ltr"
          title={value}
        >
          {value}
        </span>
        <CopyValue value={value} />
      </dd>
    </div>
  );
}

function ChangesList({
  changes,
}: {
  changes: ReturnType<typeof describeAudit>["changes"];
}) {
  return (
    <ul className="divide-y divide-line rounded-xl border border-line">
      {changes.map((c) => (
        <li
          key={c.field}
          className={cn(
            "flex flex-wrap items-center gap-x-3 gap-y-1 px-3.5 py-2.5 text-sm",
            c.highlight && "bg-accent-soft/60",
          )}
        >
          <span className="w-28 shrink-0 font-medium">{c.label}</span>
          <span
            className="num rounded bg-[var(--red-bg)] px-1.5 text-[var(--red-fg)]"
            dir="auto"
          >
            {c.before}
          </span>
          <ArrowRight
            className="size-3.5 text-faint rtl:rotate-180"
            aria-hidden
          />
          <span
            className="num rounded bg-[var(--green-bg)] px-1.5 text-[var(--green-fg)]"
            dir="auto"
          >
            {c.after}
          </span>
        </li>
      ))}
    </ul>
  );
}

function EntryDetails({
  log,
  onFilterActor,
}: {
  log: AuditLog;
  onFilterActor: (id: string) => void;
}) {
  const { t, lang } = useI18n();
  const label = useEnumLabel();
  const { ctx, entityName, targetText, actorName } = useAuditText();
  const d = describeAudit(log, ctx);
  const href = entityHref(log.entity, log.entityId, log.action);
  const hasDetails = d.facts.length > 0 || d.changes.length > 0;

  return (
    <div className="space-y-5">
      {d.summary && !d.summaryIsChanges && (
        <p className="rounded-xl bg-surface-2 px-4 py-3 text-sm font-medium leading-relaxed">
          {d.summary}
        </p>
      )}

      <dl className="grid grid-cols-1 gap-4 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-xs text-faint">{t("audit.when")}</dt>
          <dd className="num">{formatDateTime(log.createdAt, lang)}</dd>
        </div>
        <div>
          <dt className="text-xs text-faint">{t("audit.performedBy")}</dt>
          <dd>
            <span className="font-medium" dir="auto">
              {actorName(log)}
            </span>
            {log.actor && (
              <>
                <span className="ms-2">
                  <Tag>{label("role", log.actor.role)}</Tag>
                </span>
                <span className="mt-0.5 block text-xs text-muted">
                  <bdi dir="ltr">{log.actor.email}</bdi>
                </span>
                <button
                  type="button"
                  className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-accent hover:underline focus-visible:outline-2"
                  onClick={() => onFilterActor(log.actor!.id)}
                >
                  <Filter className="size-3" aria-hidden />
                  {t("audit.onlyThisPerson")}
                </button>
              </>
            )}
          </dd>
        </div>
        <div className="sm:col-span-2">
          <dt className="text-xs text-faint">{t("audit.target")}</dt>
          <dd className="flex flex-wrap items-center gap-2">
            <Tag>{entityName(log.entity)}</Tag>
            <span dir="auto" className={cn(!log.entityLabel && "text-muted")}>
              {targetText(log)}
            </span>
            {href && log.entityLabel && (
              <Link
                to={href}
                className="inline-flex items-center gap-1 text-xs font-medium text-accent hover:underline"
              >
                {t("audit.openRecord")}
                <ExternalLink className="size-3 rtl:-scale-x-100" aria-hidden />
              </Link>
            )}
          </dd>
        </div>
      </dl>

      {d.changes.length > 0 && (
        <section>
          <h3 className="mb-2 text-xs font-semibold text-faint">
            {t("audit.changes")}
          </h3>
          <ChangesList changes={d.changes} />
        </section>
      )}

      {d.facts.length > 0 && (
        <section>
          <h3 className="mb-2 text-xs font-semibold text-faint">
            {t("audit.details")}
          </h3>
          <dl className="divide-y divide-line rounded-xl border border-line text-sm">
            {d.facts.map((f) => (
              <div
                key={f.key}
                className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-0.5 px-3.5 py-2.5"
              >
                <dt className="text-muted">{f.label}</dt>
                <dd className="font-medium" dir="auto">
                  {f.href ? (
                    <Link to={f.href} className="text-accent hover:underline">
                      {f.value}
                    </Link>
                  ) : (
                    f.value
                  )}
                </dd>
              </div>
            ))}
          </dl>
        </section>
      )}

      {(!d.summary || d.summaryIsChanges) && !hasDetails && !d.changes.length && (
        <p className="text-sm text-muted">{t("audit.noDetails")}</p>
      )}

      <details className="group rounded-xl border border-line">
        <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-3.5 py-2.5 text-xs font-medium text-muted hover:text-ink">
          {t("audit.technical")}
          <ChevronDown
            className="size-4 transition-transform group-open:rotate-180"
            aria-hidden
          />
        </summary>
        <dl className="divide-y divide-line border-t border-line px-3.5">
          <TechnicalRow label={t("audit.entryId")} value={log.id} />
          {log.userId && (
            <TechnicalRow label={t("audit.actorId")} value={log.userId} />
          )}
          {log.entityId && (
            <TechnicalRow label={t("audit.recordId")} value={log.entityId} />
          )}
          <TechnicalRow label={t("audit.ip")} value={log.ipAddress ?? "—"} />
        </dl>
      </details>
    </div>
  );
}

export default function AuditLogsPage() {
  const { t, lang } = useI18n();
  const label = useEnumLabel();
  const { ctx, entityName, targetText, actorName } = useAuditText();
  const { state, update, reset } = useListParams({
    sortBy: "createdAt",
    sortOrder: "DESC",
  });
  const f = state.filters;
  const params = {
    page: state.page,
    limit: state.limit,
    sortBy: state.sortBy,
    sortOrder: state.sortOrder,
    action: f.action,
    entity: f.entity,
    userId: f.userId,
  };
  const q = useQuery({
    queryKey: ["audit-logs", "list", params],
    queryFn: () => auditLogsApi.list(params),
    placeholderData: (p) => p,
  });
  const [open, setOpen] = useState<AuditLog | null>(null);
  // only the user filter needs the user list; names in the table come from the API itself
  const users = useAllUsers();
  const filteredActor = useMemo(() => {
    if (!f.userId) return null;
    const fromRows = q.data?.data.find((l) => l.userId === f.userId)?.actor;
    return fromRows ?? users.data?.find((u) => u.id === f.userId) ?? null;
  }, [f.userId, q.data, users.data]);

  const filterByActor = (id: string) => {
    update({ filters: { userId: id }, page: 1 });
    setOpen(null);
  };

  const fields: FilterField[] = [
    {
      type: "select",
      key: "action",
      label: t("audit.action"),
      options: AuditAction.map((v) => ({ value: v, label: label("audit", v) })),
    },
    {
      type: "select",
      key: "entity",
      label: t("audit.entity"),
      options: ENTITIES.map((v) => ({ value: v, label: entityName(v) })),
    },
    {
      type: "user",
      key: "userId",
      label: t("audit.userId"),
      users: users.data ?? [],
      placeholder: t("audit.searchUser"),
    },
  ];

  const columns: Column<AuditLog>[] = [
    {
      key: "when",
      header: t("audit.when"),
      sortKey: "createdAt",
      cell: (l) => (
        <span className="num whitespace-nowrap text-muted">
          {formatDateTime(l.createdAt, lang)}
        </span>
      ),
    },
    {
      key: "actor",
      header: t("audit.actor"),
      cell: (l) => (
        <div className="min-w-0">
          <p className="truncate text-sm font-medium" dir="auto">
            {actorName(l)}
          </p>
          {l.actor && (
            <p className="truncate text-xs text-muted">
              {label("role", l.actor.role)}
            </p>
          )}
        </div>
      ),
    },
    {
      key: "action",
      header: t("audit.what"),
      cell: (l) => {
        const d = describeAudit(l, ctx);
        return (
          <div className="min-w-0">
            <p className="font-medium">{label("audit", l.action)}</p>
            {d.summary && (
              <p className="max-w-[20rem] truncate text-xs text-muted" dir="auto" title={d.summary}>
                {d.summary}
              </p>
            )}
          </div>
        );
      },
    },
    {
      key: "entity",
      header: t("audit.target"),
      cell: (l) => (
        <div className="flex min-w-0 max-w-[17rem] items-center gap-2">
          <span className="shrink-0 whitespace-nowrap">
            <Tag>{entityName(l.entity)}</Tag>
          </span>
          <span
            className={cn(
              "min-w-0 truncate text-sm",
              !l.entityLabel && "text-muted",
            )}
            dir="auto"
            title={targetText(l)}
          >
            {targetText(l)}
          </span>
        </div>
      ),
    },
    {
      key: "details",
      header: "",
      cell: (l) => (
        <Button
          size="sm"
          variant="ghost"
          onClick={(e) => {
            e.stopPropagation();
            setOpen(l);
          }}
        >
          {t("audit.expand")}
        </Button>
      ),
    },
  ];
  const has = Object.values(f).some(Boolean);

  return (
    <>
      <PageHeader
        icon={History}
        badge={<CountBadge n={q.data?.meta.total} />}
        title={t("audit.title")}
        subtitle={t("audit.sub")}
        actions={
          <ExportButton
            filename="audit-log"
            disabled={!q.data?.meta.total}
            fetchRows={() =>
              fetchAll((page, limit) => auditLogsApi.list({ ...params, page, limit }))
            }
            columns={[
              { header: t("export.col.when"), value: (l) => formatDateTime(l.createdAt, lang) },
              { header: t("export.col.actor"), value: (l) => actorName(l) },
              { header: t("export.col.email"), value: (l) => l.actor?.email },
              { header: t("export.col.action"), value: (l) => label("audit", l.action) },
              { header: t("export.col.type"), value: (l) => entityName(l.entity) },
              { header: t("export.col.record"), value: (l) => targetText(l) },
              { header: t("export.col.details"), value: (l) => describeAudit(l, ctx).summary },
            ]}
          />
        }
      />
      <FilterBar
        className="mb-3"
        fields={fields}
        values={f}
        onChange={(patch) => update({ filters: patch })}
        onReset={reset}
      />
      {f.userId && (
        <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-accent-soft px-3 py-1.5 text-xs font-medium">
          {t("audit.showingFor", {
            name: filteredActor ? fullName(filteredActor) : t("audit.actor"),
          })}
          <button
            type="button"
            aria-label={t("common.clearFilters")}
            className="rounded-full p-0.5 hover:bg-surface focus-visible:outline-2"
            onClick={() => update({ filters: { userId: undefined }, page: 1 })}
          >
            <X className="size-3.5" aria-hidden />
          </button>
        </p>
      )}
      <DataTable
        columns={columns}
        data={q.data?.data}
        isLoading={q.isLoading}
        error={q.error}
        onRetry={() => q.refetch()}
        rowKey={(l) => l.id}
        page={state.page}
        limit={state.limit}
        total={q.data?.meta.total ?? 0}
        totalPages={q.data?.meta.totalPages ?? 1}
        onPageChange={(page) => update({ page })}
        onLimitChange={(limit) => update({ limit, page: 1 })}
        sort={{ sortBy: state.sortBy, sortOrder: state.sortOrder }}
        onSortChange={(s) => update({ ...s, page: 1 })}
        onRowClick={setOpen}
        emptyState={
          has ? (
            <EmptyState variant="no-results" onClear={reset} />
          ) : (
            <EmptyState icon={ScrollText} title={t("audit.empty")} />
          )
        }
        mobileCard={(l) => {
          const d = describeAudit(l, ctx);
          return (
            <div className="space-y-1.5">
              <p className="font-semibold">{label("audit", l.action)}</p>
              {d.summary && (
                <p className="text-xs text-muted" dir="auto">
                  {d.summary}
                </p>
              )}
              <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted">
                <Tag>{entityName(l.entity)}</Tag>
                <span dir="auto">{targetText(l)}</span>
              </p>
              <p className="text-xs text-faint">
                <span dir="auto">{actorName(l)}</span> ·{" "}
                <span className="num">{formatDateTime(l.createdAt, lang)}</span>
              </p>
            </div>
          );
        }}
      />
      <Dialog
        open={!!open}
        onOpenChange={(o) => !o && setOpen(null)}
        title={open ? label("audit", open.action) : ""}
        className="max-w-xl"
      >
        {open && <EntryDetails log={open} onFilterActor={filterByActor} />}
      </Dialog>
    </>
  );
}
