import type {
  AuditAction,
  LeaseRenewalRequestStatus,
  LeaseStatus,
  MaintenanceCategory,
  MaintenancePriority,
  MaintenanceStatus,
  NotificationType,
  PropertyType,
  RentalRequestStatus,
  UnitStatus,
  UserRole,
} from "./enums";

export interface ImageRef {
  url: string;
  publicId: string;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string | null;
  role: UserRole;
  roleSelected: boolean;
  ownerVerified: boolean;
  avatar: ImageRef | null;
  isActive: boolean;
  isEmailVerified: boolean;
  images?: ImageRef[];
  createdAt: string;
  updatedAt: string;
}
export interface DirectoryUser {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
}

export interface Property {
  id: string;
  name: string;
  description: string | null;
  propertyType: PropertyType;
  address: string;
  city: string;
  country: string;
  ownerId: string;
  images: ImageRef[];
  createdAt: string;
  updatedAt: string;
  /** Present only when a TENANT reads GET /properties/:id */
  units?: Unit[];
}

export interface Unit {
  id: string;
  unitNumber: string;
  floor: number | null;
  area: number;
  rentAmount: number;
  bedrooms: number;
  bathrooms: number;
  description: string | null;
  propertyId: string;
  status: UnitStatus;
  images: ImageRef[];
  createdAt: string;
  updatedAt: string;
}
export interface UnitSummary {
  id: string;
  unitNumber: string;
  propertyId: string;
}

export interface TenantSummary {
  id: string;
  firstName: string;
  lastName: string;
  phone: string | null;
}

export interface RentalRequest {
  id: string;
  tenantId: string;
  unitId: string;
  startDate: string;
  endDate: string;
  message: string | null;
  status: RentalRequestStatus;
  rentAmount: number;
  leaseId: string | null;
  tenant?: TenantSummary;
  unit?: {
    id: string;
    unitNumber: string;
    propertyId: string;
    rentAmount: number;
  };
  createdAt: string;
  updatedAt: string;
}

export interface Lease {
  id: string;
  tenantId: string;
  unitId: string;
  unit: UnitSummary;
  startDate: string;
  endDate: string;
  rentAmount: number;
  status: LeaseStatus;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface LeaseRenewalRequest {
  id: string;
  leaseId: string;
  tenantId: string;
  requestedEndDate: string;
  message: string | null;
  status: LeaseRenewalRequestStatus;
  createdAt: string;
  updatedAt: string;
  tenant?: TenantSummary;
  lease?: {
    id: string;
    startDate: string;
    endDate: string;
    status: LeaseStatus;
    rentAmount: number;
  };
  unit?: UnitSummary;
}

export interface MaintenanceRequest {
  id: string;
  title: string;
  description: string;
  category: MaintenanceCategory;
  priority: MaintenancePriority;
  images: ImageRef[];
  unitId: string;
  unit: UnitSummary;
  tenantId: string;
  status: MaintenanceStatus;
  assignedStaffId: string | null;
  scheduledDate: string | null;
  completionImages: ImageRef[];
  resolutionDescription: string | null;
  resolvedAt: string | null;
  createdAt: string;
  updatedAt: string;
}
export interface MaintenanceHistoryItem {
  id: string;
  requestId: string;
  previousStatus: MaintenanceStatus | null;
  newStatus: MaintenanceStatus;
  changedById: string;
  notes: string | null;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  isRead: boolean;
  relatedEntityType: string | null;
  relatedEntityId: string | null;
  createdAt: string;
}

/** Who performed an audit action (sent by the API, so the UI never needs a user lookup). */
export interface AuditActor {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
}

/** A record mentioned in an entry's metadata; `label` is null when it no longer exists. */
export interface AuditRef {
  entity: string;
  id: string;
  label: string | null;
}

export interface AuditLog {
  id: string;
  userId: string | null;
  action: AuditAction | string;
  entity: string;
  entityId: string | null;
  metadata: Record<string, unknown> | null;
  ipAddress: string | null;
  createdAt: string;
  /** Display data added by the API. Optional so an older backend still works. */
  actor?: AuditActor | null;
  entityLabel?: string | null;
  refs?: Record<string, AuditRef>;
}

export interface DashboardStats {
  totalProperties: number;
  totalUnits: number;
  occupiedUnits: number;
  availableUnits: number;
  occupancyRate: number;
  activeLeases: number;
  expiredLeases: number;
  openMaintenanceRequests: number;
  resolvedMaintenanceRequests: number;
  avgMaintenanceResolutionHours: number | null;
  mostCommonMaintenanceCategories: {
    category: MaintenanceCategory | string;
    count: number;
  }[];
}

export interface LoginResult {
  accessToken: string;
  expiresIn: number;
  user: User;
}
